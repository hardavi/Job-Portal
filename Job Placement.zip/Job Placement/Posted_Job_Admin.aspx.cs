﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Security;
using System.Data;
using System.Data.SqlClient;

public partial class PostedJob : System.Web.UI.Page
{
   // SqlConnection con = new SqlConnection(@"Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
    SqlDataAdapter adp = new SqlDataAdapter();
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    
    
    protected void btn_save_Click(object sender, EventArgs e)
    {
        string qry = "insert into [Job_Posted](Job_Post_Company_Name, Job_Post_Title, Job_Post_Area, Job_Post_Number_Of_Vacancy, Job_Post_Start_Date, Job_Post_End_Date, Job_Post_Experience_Requried, Job_Post_Skill_Requried, Job_Post_Education_Required, Job_Post_Basic_Required, Job_Post_Salary, Job_Post_Work_Time, Job_Post_Status) values('" + txt_job_post_company_name.Text +"','" + txt_job_post_title.Text +"','" + txt_area_name.Text +"','" + txt_no_of_vacancy.Text +"','" + txt_start_date.Text +"','" + txt_end_date.Text +"','" + txt_experience_required.Text +"','" + txt_skill_required.Text +"','" + txt_educaiton_requied.Text +"','" + txt_basic_required.Text +"','" + txt_salary.Text +"','" + DropDownList1.SelectedItem.Value +"','" + txt_status.Text +"')";
        SqlCommand cmd = new SqlCommand(qry, con);
        con.Open();
        cmd.ExecuteNonQuery();

        Response.Redirect("http://localhost:17217/Job Placement/Home_Page.aspx");
        con.Close();
    
    }
}