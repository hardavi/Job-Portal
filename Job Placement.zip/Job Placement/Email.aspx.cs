﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;

public partial class Email : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow row in GridView1.Rows)
        {
            CheckBox chk = (row.Cells[2].FindControl("CheckBox2") as CheckBox);
            string emailadd = row.Cells[1].Text;
            if (chk.Checked)
            {
                SendCandMail(emailadd);
            }
        }
    }

    private void SendCandMail(string emailadd1)
    {
        SmtpClient smtp = new SmtpClient();
        smtp.Host = "smtp.gmail.com";
        smtp.Port = 587;

        smtp.Credentials = new System.Net.NetworkCredential("Dreameredjob@gmail.Com", "Job@$*1956");
        smtp.EnableSsl = true;
       
        MailMessage msg = new MailMessage();
        msg.Subject = txt_sub.Text;
        msg.Body = txt_msg.Text + "\n\n\nThanks & Regard.\nDream Job Team";

        string toaddress = emailadd1;
        msg.To.Add(toaddress);

        string fromaddress = "Dream Job Team <Dreameredjob@gmail.Com>";
        msg.From = new MailAddress(fromaddress);

        try
        {
            smtp.Send(msg);
        }
        catch
        {
            
            throw;
        }
        Response.Write("Email Sent to:- " + emailadd1);
    }
}