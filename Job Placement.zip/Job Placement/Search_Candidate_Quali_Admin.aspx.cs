﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.Security;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Search_Candidate : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
  
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            SqlDataAdapter adp = new SqlDataAdapter();
            DataSet ds = new DataSet();
            string qry = null;
            con.Open();
            qry = "select Candidate_UserName, Tenth_Percentage, Tenth_School_Name, Twelveth_Percentage, Twelveth_School_Name, Graduation_Percentage, Graduation_College_Name, Graduation_Degree_Name, Post_Graduation_Percentage, Post_Graduation_College_Name, Post_Graduation_Degree_Name, Other_Certification from Candidate_Education";
            SqlCommand cmd = new SqlCommand(qry, con);
            adp.SelectCommand = cmd;
            adp.Fill(ds);
            adp.Dispose();
            cmd.Dispose();
            con.Close();

            // GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();

        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
    protected void btnapply_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://localhost:37704/Job Placement/Search_Candidate_Quali_Admin_Email.aspx");
    }
}