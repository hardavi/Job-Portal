﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Data.SqlClient*;

public partial class zem : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();
        }
    }

    protected void  GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        GridView1.DataSource = SqlDataSource1;
        GridView1.DataBind();
        lblmsg.Text = " ";
        GridView1.EditRowStyle.BackColor = System.Drawing.Color.Orange;
    }

    protected void  GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        GridView1.DataSource = SqlDataSource1;
        GridView1.DataBind();
        lblmsg.Text = " ";
    }
    
    protected void  GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        Label id = GridView1.Rows[e.RowIndex].FindControl("Label4") as Label;
        TextBox name = GridView1.Rows[e.RowIndex].FindControl("TextBox1") as TextBox;
        TextBox email = GridView1.Rows[e.RowIndex].FindControl("TextBox2") as TextBox;

        string mycon = "Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Documents\emp.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
        string updatedata = "Update emp set empName = '" + name.Text + "', empEmail = '" + email.Text + "' where empID = '" + id.Text + "' ";

        SqlConnection con = new SqlConnection(mycon);
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = updatedata;
        cmd.Connection = con;
        cmd.ExecuteNonQuery();
        lblmsg.Text = "Inserted";

        GridView1.EditIndex = -1;
        SqlDataSource1.DataBind();
        GridView1.DataSource = SqlDataSource1;
        GridView1.DataBind();
    }
}