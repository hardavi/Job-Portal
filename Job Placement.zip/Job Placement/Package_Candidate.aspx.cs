﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Security;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class Package_Candidate : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
            SqlDataAdapter adp = new SqlDataAdapter();
            DataSet ds = new DataSet();
            string qry = null;
            con.Open();
            qry = "select Candidate_Fname, Candidate_Mname, Candidate_Phone_Number, Candidate_Email_ID, Candidate_Addhar_Number, Candidate_City from Candidate";
            SqlCommand cmd = new SqlCommand(qry, con);
            adp.SelectCommand = cmd;
            adp.Fill(ds);
            adp.Dispose();
            cmd.Dispose();
            con.Close();

            // GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
        }
    }

  
    protected void btn_apply_Click(object sender, EventArgs e)
    {
        string data = "";
        foreach (GridViewRow row in GridView1.Rows)
        {
            if (row.RowType == DataControlRowType.DataRow)
            {
                CheckBox chk = (row.Cells[0].FindControl("CheckBox2") as CheckBox);
                if (chk.Checked)
                {
                    string cname = row.Cells[5].Text;
                    string salary = row.Cells[2].Text;
                    string desi = row.Cells[3].Text;
                    //string vacancy = row.Cells[4].Text;
                   
                    data = "<br>" + "Company Name:- " + cname + "<br/>" + " Salary:-  " + salary + "<br/>" + " Designation:-  " + desi + "<br/>" ;
                }
            }
        }
        lblmsg.Text = data;
    }
    
}