﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Net;

public partial class Forgot_Pwd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string password;
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
        string qry = "select * from Login where UserName='" + txt_uname.Text + "' and Email_ID='" + txt_email.Text + "'";

        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = qry;
        cmd.Connection = con;

        SqlDataAdapter adp = new SqlDataAdapter();
        adp.SelectCommand = cmd;

        DataSet ds = new DataSet();
        adp.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
            password = ds.Tables[0].Rows[0]["Password"].ToString();
            SendPassword(password, txt_email.Text);
            Response.Redirect("http://localhost:37704/Job Placement/Log-In.aspx");
        }
        else
        {
            Label1.Text = "Your Username And Password Invalid";
        }
        con.Close();
    }

    private void SendPassword(string password, string email)
    {
        SmtpClient smtp = new SmtpClient();
        smtp.Host = "smtp.gmail.com";
        smtp.Port = 587;

        smtp.Credentials = new System.Net.NetworkCredential("dreameredjob@gmail.com", "Job@$*1956");
        smtp.EnableSsl = true;

        MailMessage msg = new MailMessage();
        msg.Subject = "Forgot Password [Dream Job]";
        msg.Body = "Dear " + txt_uname.Text + ",\n Your Password is:- " + password + "\n\n\nThanks & Regard.\nDream Job Team";

        string toaddress = txt_email.Text;
        msg.To.Add(toaddress);

        string fromaddress = "Dream Job Team <dreameredjob@gmail.com>";
        msg.From = new MailAddress(fromaddress);

        try
        {
            smtp.Send(msg);
        }
        catch
        {
            throw;
        }
    }
}