﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Security;
using System.Data;
using System.Data.SqlClient;

public partial class Company_Package_cand : System.Web.UI.Page
{
    SqlConnection con = null;
    SqlDataAdapter adp = null;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void btn_add_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
        con.Open();

        string qry = "select Package.Package_ID , Package.Package_Cost , Package.Package_Job_Post , Package.Number_of_post , Company_Package.Package_Date,Company.Company_Name from Package inner join Company_Package on Package.Package_ID = Company_Package.Package_ID inner join Company on Company_Package.Company_ID = Company.Company_ID";
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();

    }
}