﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.Security;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_Category : System.Web.UI.Page
{
    SqlConnection con = null;
    SqlDataAdapter adp = null;

    public void category()
    {
        con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
        con.Open();

        string qry = "select * from Category";
        adp = new SqlDataAdapter(qry, con);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        DropDownList1.DataSource = ds.Tables[0];
        DropDownList1.DataTextField="Category_Name && Category_Status";
        DropDownList1.DataValueField = "Category_ID";
        DropDownList1.DataBind();
        DropDownList1.Items.Insert(0, new ListItem("select", "0"));

        con.Close();
    }
    /*
    public void area()
    {
        con=new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
        con.Open();

        string qry = "select * from Area";
        adp = new SqlDataAdapter(qry, con);
        DataSet ds = new DataSet();
        adp.Fill(ds);
        DropDownList2.DataSource = ds.Tables[0];
        DropDownList2.DataTextField = "Area_Name";
        DropDownList2.DataValueField="Area_ID";
        DropDownList2.DataBind();
        DropDownList2.Items.Insert(0, new ListItem("select", "0"));

        con.Close();
    }
    */
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            category();
           // area();
        }
    }


    protected void btn_category_Add_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
        con.Open();

        string qry = "insert into Category(Category_Name,Category_Status) values('" + txt_category.Text + "' , '" + txt_category_status.Text + "' )";
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();
        clear();
    }

    /*protected void btn_add_area_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
        con.Open();

        string qry="insert into Area(
    }
    */
    protected void btn_add_post_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
        con.Open();

        string qry="insert into Post(Post_Name,Post_Work_Time) values('" + txt_post.Text + "','" + txt_post_timing.Text +"')";
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();
        clear();
    }

    public void clear()
    {
        txt_area.Text = "";
        txt_category.Text = "";
        txt_post.Text = "";
        txt_category_status.Text = "";
    }
}