﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Security;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class New_Package : System.Web.UI.Page
{
    SqlConnection con = null;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_add_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
        con.Open();

        string qry = "insert into Package(Package_Cost,Package_Job_Post,Number_of_post) values ('" + txt_cost.Text + "','" + txt_job_post.Text + "','" + txt_no_of_post.Text + "')";
       
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();
        Clear();
    }

    public void Clear()
    {
        txt_cost.Text = "";
        txt_job_post.Text = "";
        txt_no_of_post.Text = "";
    }
  
    protected void btn_view_Click(object sender, EventArgs e)
    {
        con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
        con.Open();
        string query = "select * from Package";

        SqlCommand cmd1 = new SqlCommand(query, con);
        cmd1.ExecuteNonQuery();
        Response.Redirect("http://localhost:37704/Job Placement/Home_Page_Comp.aspx");

        con.Close();
    }
   
    protected void btn_prev_Click(object sender, EventArgs e)
    {
        Response.Redirect("http://localhost:37704/Job Placement/Posted_Job_Company.aspx");
    }
}
