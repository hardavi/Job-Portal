﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Security;
using System.Data;
using System.Data.SqlClient;

public partial class Candidate_Qualification_Cand : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
   
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {
      
        con.Open();
        string qry = "insert into [Candidate_Education](Candidate_UserName, Tenth_Percentage, Tenth_School_Name, Twelveth_Percentage, Twelveth_School_Name, Graduation_Percentage, Graduation_College_Name, Graduation_Degree_Name, Post_Graduation_Percentage, Post_Graduation_College_Name, Post_Graduation_Degree_Name, Other_Certification) values('" + txt_uname.Text + "','" + txt_10_per.Text + "','" + txt_10_sname.Text + "','" + txt_12_per.Text + "','" + txt_12_sname.Text + "','" + txt_grad_per.Text + "','" + txt_grad_clg_name.Text + "','" + txt_grad_degree_name.Text + "',  '" + txt_post_grad_per.Text + "','" + txt_post_grad_clg_name.Text + "','" + txt_post_grad_degree_name.Text + "','" + txt_other_certi.Text + "')";
        SqlCommand cmd = new SqlCommand(qry, con);
        cmd.ExecuteNonQuery();

        Response.Redirect("Home_Page_Cand.aspx");
        con.Close();
    } 
}