﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data;

public partial class Login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
    
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void btnlogin_Click(object sender, EventArgs e)
    {
        string qry = "select count(*) from Login where UserName='" + txtname.Text + "' and Password='" + txtpass.Text + "' and Role = '" + drop_role.SelectedValue + "'";
        SqlCommand cmd = new SqlCommand(qry, con);
        con.Open();
        /*if (drop_role.SelectedValue == "Candidate")
            {
                Response.Redirect("http://localhost:17217/Job Placement/Candidate _Regi.aspx");
            }
            else if (drop_role.SelectedValue == "Company")
            {
                Response.Redirect("http://localhost:17217/Job Placement/Company_Regi.aspx");
            }
            else if (drop_role.SelectedValue == "Recruiter")
            {
                Response.Redirect("http://localhost:17217/Job Placement/Recruiter_Profile.aspx");
            }
       */
        int temp = Convert.ToInt32(cmd.ExecuteScalar().ToString());
        con.Close();
        if (temp == 1)
        {
            Response.Redirect("http://localhost:17217/Job Placement/Home_Page.aspx");
        }
        
        else
        {
            lblmessage.Text = "Your Username or Password not match";
        }
        //con.Close();
    }
}