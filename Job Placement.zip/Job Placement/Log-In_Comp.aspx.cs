﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data;

public partial class Log_In_Comp : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd;
    SqlDataAdapter adp;
    DataTable dt;
    int rowcount;
    string qry, cname, email;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        qry = "select * from Company";
        cmd = new SqlCommand(qry, con);
        adp = new SqlDataAdapter(cmd.CommandText, con);
        dt = new DataTable();
        adp.Fill(dt);
        rowcount = dt.Rows.Count;
        for (int i = 0; i < rowcount; i++)
        {
            cname = dt.Rows[i]["Company_Name"].ToString();
            email = dt.Rows[i]["Company_Email_ID"].ToString();
            if (cname == txt_comp_name.Text && email == txt_email.Text)
            {
                Session["Company_Name"] = cname;
                Response.Redirect("http://localhost:37704/Job Placement/Posted_Job_Company.aspx");
            }
            else
            {
                lblmessage.Text = "Your Username or Password not match";
            }

        }
    }
}