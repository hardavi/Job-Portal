﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class Log_In : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd;
    SqlDataAdapter adp;
    DataTable dt;
    int rowcount;
    string qry, uname, pass;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        qry = "select * from Login";
        cmd = new SqlCommand(qry,con);
        adp = new SqlDataAdapter(cmd.CommandText, con);
        dt = new DataTable();
        adp.Fill(dt);
        rowcount = dt.Rows.Count;
        for (int i = 0; i < rowcount; i++)
        {
            uname = dt.Rows[i]["UserName"].ToString();
            pass = dt.Rows[i]["Password"].ToString();
            if (uname == txtname.Text && pass == txtpass.Text)
            {
                Session["UserName"] = uname;
                if (dt.Rows[i]["Role"].ToString() == "Admin")
                    Response.Redirect("http://localhost:37704/Job Placement/Home_Page_Admin.aspx");
                else if (dt.Rows[i]["Role"].ToString() == "Candidate")
                    Response.Redirect("http://localhost:37704/Job Placement/Home_Page_Cand.aspx");
                else if (dt.Rows[i]["Role"].ToString() == "Company")
                    Response.Redirect("http://localhost:37704/Job Placement/Home_Page_Comp.aspx");
            }
            else
            {
                lblmessage.Text = "Your Username or Password not match";
            }

        }
    }
}


