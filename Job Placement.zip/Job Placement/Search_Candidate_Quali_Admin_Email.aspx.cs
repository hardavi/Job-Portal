﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Search_Candidate_Quali_Admin_Email : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd = new SqlCommand();
    SqlDataAdapter adp;


    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        string qry = "select * from Candidate_Education where Candidate_UserName like '%'+@Candidate_UserName+'%' ";
        cmd.CommandText = qry;
        cmd.Connection = con;
        cmd.Parameters.AddWithValue("Candidate_UserName", TextBox1.Text);
        DataTable dt = new DataTable();
        adp = new SqlDataAdapter(cmd);
        adp.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();

    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }



    protected void btnapply_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow row in GridView1.Rows)
        {
            SqlCommand cmd = new SqlCommand("insert into Employee_Education(Candidate_UserName, Tenth_Percentage, Tenth_School_Name, Twelveth_Percentage, Twelveth_School_Name, Graduation_Percentage, Graduation_College_Name, Graduation_Degree_Name, Post_Graduation_Percentage, Post_Graduation_College_Name, Post_Graduation_Degree_Name, Other_Certification) values ('" + row.Cells[0].Text + "', '" + row.Cells[1].Text + "', '" + row.Cells[2].Text + "', '" + row.Cells[3].Text + "', '" + row.Cells[4].Text + "', '" + row.Cells[5].Text + "', '" + row.Cells[6].Text + "', '" + row.Cells[7].Text + "', '" + row.Cells[8].Text + "', '" + row.Cells[9].Text + "', '" + row.Cells[10].Text + "', '" + row.Cells[11].Text + "')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            Response.Redirect("http://localhost:37704/Job Placement/Home_Page_Admin.aspx");
        }
    }
}