﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Security;
using System.Data;
using System.Data.SqlClient;

public partial class Hire_Candidate_Comp : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
            
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {

            refreshdata();
        }
    }

    public void refreshdata()
    {
       
        SqlCommand cmd = new SqlCommand("select * from Job_Apply", con);
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        adp.Fill(dt);
        Gv1.DataSource = dt;
        Gv1.DataBind();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow row in Gv1.Rows)
        {
            var chk = row.FindControl("CheckBox1") as CheckBox;
            if (chk.Checked)
            {
                var lid = row.FindControl("lblid") as Label;
                var lfname = row.FindControl("lblfname") as Label;
                var lmname = row.FindControl("lblmname") as Label;
                var lpno = row.FindControl("lblpno") as Label;
                var lemail = row.FindControl("lbleid") as Label;
                var ladhar = row.FindControl("lbladhar") as Label;
                var lcity = row.FindControl("lblcity") as Label;
                var llname = row.FindControl("lbllname") as Label;
                var luname = row.FindControl("lbluname") as Label;
                var ldob = row.FindControl("lbldob") as Label;
                var lcate = row.FindControl("lblcate") as Label;
                var lcountry = row.FindControl("lblcountry") as Label;
                var lstate = row.FindControl("lblstate") as Label;
                var larea = row.FindControl("lblarea") as Label;
                var ladd = row.FindControl("lbladd") as Label;
                var lgen = row.FindControl("lblgen") as Label;

                SqlCommand cmd = new SqlCommand("insert into Employee(Candidate_ID, Candidate_Fname, Candidate_Mname, Candidate_Lname, Candidate_Username, Candidate_Gender, Candidate_DOB, Candidate_Phone_Number, Candidate_Email_ID, Candidate_Addhar_Number, Candidate_Categotry, Candidate_Country, Candidate_State, Candidate_City, Candidate_Area, Candidate_Address) values (@Candidate_ID, @Candidate_Fname, @Candidate_Mname, @Candidate_Lname, @Candidate_Username, @Candidate_Gender, @Candidate_DOB, @Candidate_Phone_Number, @Candidate_Email_ID, @Candidate_Addhar_Number, @Candidate_Categotry, @Candidate_Country, @Candidate_State, @Candidate_City, @Candidate_Area, @Candidate_Address)", con);
                cmd.Parameters.AddWithValue("Candidate_ID", lid.Text);
                cmd.Parameters.AddWithValue("Candidate_Fname", lfname.Text);
                cmd.Parameters.AddWithValue("Candidate_Mname", lmname.Text);
                cmd.Parameters.AddWithValue("Candidate_Lname", llname.Text);
                cmd.Parameters.AddWithValue("Candidate_Username",luname.Text);
                cmd.Parameters.AddWithValue("Candidate_Gender",lgen.Text);
                cmd.Parameters.AddWithValue("Candidate_DOB",ldob.Text);
                cmd.Parameters.AddWithValue("Candidate_Phone_Number",lpno.Text);
                cmd.Parameters.AddWithValue("Candidate_Email_ID",lemail.Text);
                cmd.Parameters.AddWithValue("Candidate_Addhar_Number",ladhar.Text);
                cmd.Parameters.AddWithValue("Candidate_Categotry",lcate.Text);
                cmd.Parameters.AddWithValue("Candidate_Country",lcountry.Text);
                cmd.Parameters.AddWithValue("Candidate_State",lstate.Text);
                cmd.Parameters.AddWithValue("Candidate_City",lcity.Text);
                cmd.Parameters.AddWithValue("Candidate_Area",larea.Text);
                cmd.Parameters.AddWithValue("Candidate_Address",ladd.Text);

                con.Open();
                int i = cmd.ExecuteNonQuery();
                con.Close();
                refreshdata();
                Response.Redirect("http://localhost:37704/Job Placement/Company_Page_Comp.aspx");
            }
        }
    }
}