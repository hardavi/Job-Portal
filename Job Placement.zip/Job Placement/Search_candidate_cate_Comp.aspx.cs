﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Security;
using System.Data;
using System.Data.SqlClient;

public partial class Search_Candidate_Comp : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            SqlDataAdapter adp = new SqlDataAdapter();
            DataSet ds = new DataSet();
            string qry = null;
            con.Open();
            qry = "select Candidate_Fname, Candidate_Mname, Candidate_Gender, Candidate_DOB, Candidate_Phone_Number, Candidate_Email_ID, Candidate_State, Candidate_City from Candidate";
            SqlCommand cmd = new SqlCommand(qry, con);
            adp.SelectCommand = cmd;
            adp.Fill(ds);
            adp.Dispose();
            cmd.Dispose();
            con.Close();

            // GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();

        }
    }


    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    protected void btn_apply_Click(object sender, EventArgs e)
    {

        Response.Redirect("http://localhost:37704/Job Placement/Search_candidate_cate_Comp_Email.aspx");
    }
}