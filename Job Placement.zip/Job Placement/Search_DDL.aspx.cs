﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.HtmlControls;
using System.Security;
using System.Xml.Linq;
using System.Net;
using System.Net.Mail;

public partial class Search_DDL : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
           
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            BindCandGrid();
        }
    }

    protected void BindCandGrid()
    {
        SqlCommand cmd = new SqlCommand("select * from Demo", con);
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        adp.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string cid = string.Empty;
        DataTable dt = new DataTable();
        try
        {
            foreach (GridViewRow row in GridView1.Rows)
            {
                CheckBox chk = (CheckBox)row.FindControl("ChkSelect");

                if (chk.Checked == true)
                {
                    if (chk != null && chk.Checked)
                    {
                        cid = Convert.ToString(GridView1.DataKeys[row.RowIndex].Value);
                        SqlCommand cmd = new SqlCommand("select Candidate_Email from Demo where Candidate_ID=" + cid + "", con);
                        SqlDataAdapter adp = new SqlDataAdapter(cmd);
                        adp.Fill(dt);
                        string emailid = dt.Rows[0]["Candidate_Email"].ToString();
                        SendEmailUsingGmail(emailid);
                        dt.Clear();
                        dt.Dispose();
                    }
                }
            }
            ScriptManager.RegisterClientScriptBlock(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Emails sent successfully')", true);
            
        }
        catch (Exception ex)
        {
            Response.Write("Error Occured:- " + ex.Message.ToString());
        }
        finally
        {
            cid = string.Empty;
        }
    }

    private void SendEmailUsingGmail(string ToEmailAddress)
    {
        try
        {
            SmtpClient smtp = new SmtpClient();
            smtp.Credentials = new NetworkCredential("hardavirajyaguru@gmail.com", "99912142@Guru");
            smtp.Port = 587;
            smtp.Host = "smtp.gamil.com";
            smtp.EnableSsl = true;
            MailMessage msg = new MailMessage();

            msg.From = new MailAddress("hardavirajyaguru@gmail.com");
            msg.To.Add(ToEmailAddress);
            msg.Subject = "Write Your Email Subject Here";
            msg.Body = "Write the Content of the email here";
            smtp.Send(msg);
        }
        catch (Exception ex)
        {
            Response.Write("Error Occured:- " + ex.Message.ToString());

        }
    }


    protected void ChkSelectAll_CheckedChanged(Object sender, EventArgs e)
    {
        CheckBox chkall = (CheckBox)GridView1.HeaderRow.FindControl("ChkSelectAll");
        if (chkall.Checked == true)
        {
            foreach (GridViewRow row in GridView1.Rows)
            {
                CheckBox chksel = (CheckBox)row.FindControl("ChkSelect");
                chksel.Checked = true;

            }
        }
        else
        {
            foreach (GridViewRow row in GridView1.Rows)
            {
                CheckBox chksel = (CheckBox)row.FindControl("ChkSelect");
                chksel.Checked = false;
            }
        }
    }
}