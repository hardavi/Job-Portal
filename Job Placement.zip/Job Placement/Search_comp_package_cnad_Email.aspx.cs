﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data;
using System.Data.SqlClient;

public partial class Search_comp_package_cnad_Email : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd = new SqlCommand();
    SqlDataAdapter adp;


    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        string qry = "select * from Candidate where Candidate_Email_ID like '%'+@Candidate_Email_ID+'%' ";
        cmd.CommandText = qry;
        cmd.Connection = con;
        cmd.Parameters.AddWithValue("Candidate_Email_ID", TextBox1.Text);
        DataTable dt = new DataTable();
        adp = new SqlDataAdapter(cmd);
        adp.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();

    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnapply_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow row in GridView1.Rows)
        {
            SqlCommand cmd = new SqlCommand("insert into Job_Apply(Candidate_ID, Candidate_Fname, Candidate_Mname, Candidate_Lname, Candidate_Username, Candidate_Gender, Candidate_DOB, Candidate_Phone_Number, Candidate_Email_ID, Candidate_Addhar_Number, Candidate_Categotry, Candidate_Country, Candidate_State, Candidate_City, Candidate_Area, Candidate_Address) values ('" + row.Cells[0].Text + "', '" + row.Cells[1].Text + "', '" + row.Cells[2].Text + "', '" + row.Cells[3].Text + "', '" + row.Cells[4].Text + "', '" + row.Cells[5].Text + "', '" + row.Cells[6].Text + "', '" + row.Cells[7].Text + "', '" + row.Cells[8].Text + "', '" + row.Cells[9].Text + "', '" + row.Cells[10].Text + "', '" + row.Cells[11].Text + "', '" + row.Cells[12].Text + "', '" + row.Cells[13].Text + "', '" + row.Cells[14].Text + "', '" + row.Cells[15].Text + "')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            Response.Redirect("http://localhost:37704/Job Placement/Home_Page_Cand.aspx");
        }
    }
}