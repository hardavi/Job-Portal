﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data;

public partial class Log_in_Candidate : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
    SqlCommand cmd;
    SqlDataAdapter adp;
    DataTable dt;
    int rowcount;
    string qry, cname, email;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        qry = "select * from Candidate";
        cmd = new SqlCommand(qry, con);
        adp = new SqlDataAdapter(cmd.CommandText, con);
        dt = new DataTable();
        adp.Fill(dt);
        rowcount = dt.Rows.Count;
        for (int i = 0; i < rowcount; i++)
        {
            cname = dt.Rows[i]["Candidate_Username"].ToString();
            email = dt.Rows[i]["Candidate_Email_ID"].ToString();
            if (cname == txt_uname.Text && email == txt_email.Text)
            {
                Session["Candidate_Username"] = cname;
                Response.Redirect("Apply_For_Job_Cand.aspx");
            }
            else
            {
                lblmessage.Text = "Your Username or Password not match";
            }

        }
    }
}