﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Net.Mail;
using System.Net;
using System.Collections.Specialized;

public partial class Registration_Register : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");
    

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    public void savedata()
    {
        string qry="insert into Login(UserName, Email_ID, Role, Password, Confirm_Password, Phone_Number) values('" + txtuname.Text + "' , '" + txtemail.Text + "' , '" + drop_role.SelectedValue + "' , '" + txtpassword.Text + "', '" + txtcpassword.Text + "', '" + txt_pno.Text + "')";
        con.Open();
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = qry;
        cmd.Connection = con;
        cmd.ExecuteNonQuery();
        lmsg.Text = "Successfully Registered";
    }

    protected void btnregister_Click(object sender, EventArgs e)
    {
      //  Random rm = new Random();
        //int value = rm.Next(100001, 999999);
        string destinationadd = "91" + txt_pno.Text;
        string msg = "Your OTP Number is" + txtuname.Text + "(sent By: Dream Job)";

        string msg1 = HttpUtility.UrlEncode(msg);

        using (var wb = new WebClient())
        {
            byte[] response = wb.UploadValues("https://api.textlocal.in/send/", new NameValueCollection()
            {
                {"apikey", "MKmqf5kctA0-6pQktAp4G6HOHBLkUDEc4YZCvCyAzz"},
                {"numbers",destinationadd},
                {"message",msg1},
                {"sender","TXTLCL"}
            });

            string result = System.Text.Encoding.UTF8.GetString(response);
            savedata();
            lmsg.Text = "Welcome";
        }
        Response.Redirect("http://localhost:17217/Job Placement/Login/Login.aspx");
        

    }

        
    protected void  btnclear_Click(object sender, EventArgs e)
    {
        txtuname.Text = "";
        txtpassword.Text = "";
        txtcpassword.Text = "";
        txtemail.Text = "";
       // RadioButtonList1.ClearSelection();
        txt_pno.Text = "";
    }
}