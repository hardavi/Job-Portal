﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.Security;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Search_Jobs : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\manis\Desktop\project_asp.net\Website\Job Placement\App_Data\Job_Placement_Database.mdf;Integrated Security=True;User Instance=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        string com = "Select * from Job_Posted";
        SqlDataAdapter adpt = new SqlDataAdapter(com, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        DropDownList1.DataSource = dt;
        DropDownList1.DataBind();
        DropDownList1.DataTextField = "Job_Post_Title";
        DropDownList1.DataValueField = "Job_Post_ID";
        DropDownList1.DataBind();

        DropDownList2.DataSource = dt;
        DropDownList2.DataBind();
        DropDownList2.DataTextField = "";
        DropDownList2.DataValueField = "Job_Post_Salary";
        DropDownList2.DataBind();
    }

    protected void btn_search_Click(object sender, EventArgs e)
    {

        SqlCommand cmd = new SqlCommand("select * from Job_Posted where Job_Post_ID = '" + DropDownList1.SelectedValue + "'", con);
        SqlDataAdapter Adpt = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        Adpt.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();
    }

}