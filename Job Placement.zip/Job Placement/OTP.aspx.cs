﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
using System.Collections.Specialized;

public partial class OTP : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_otp_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = true;
        Random rm = new Random();
        int value = rm.Next(100001, 999999);
        string destinationadd = "91" + txt_mobile.Text;
        string msg = "Your OTP Number is" + value + "(sent By: Dream Job)";

        string msg1 = HttpUtility.UrlEncode(msg);

        using (var wb = new WebClient())
        {
            byte[] response = wb.UploadValues("https://api.textlocal.in/send/", new NameValueCollection()
            {
                {"apikey", "MKmqf5kctA0-6pQktAp4G6HOHBLkUDEc4YZCvCyAzz"},
                {"numbers",destinationadd},
                {"message",msg1},
                {"sender","TXTLCL"}
            });

            string result = System.Text.Encoding.UTF8.GetString(response);
            Session["otp"] = value;
        }
    }
   
    protected void btn_verify_Click(object sender, EventArgs e)
    {
        if (txt_otp.Text == Session["otp"].ToString())
        {
            Panel2.Visible = false;
            Label1.Text = "Your Mobile number is verify";
            
        }
        else
        {
            Label1.Text = "OTP is nor Correct";
            Panel2.Visible = true;
        }
    }
}